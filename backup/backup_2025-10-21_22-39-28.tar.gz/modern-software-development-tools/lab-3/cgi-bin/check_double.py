#!C:\Program Files\Python312\python.exe
# -*- coding: utf-8 -*-

import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import cgi
import html

def find_doubles(s: str):
    indexes = []
    prev = None
    for i, ch in enumerate(s):
        if i == 0:
            prev = ch
            continue
        if prev and prev.isalpha() and ch.isalpha() and prev.casefold() == ch.casefold():
            indexes.append(i-1)
        prev = ch
    return indexes

def highlight_doubles(s: str, starts):
    if not starts:
        return html.escape(s)
    out = []
    i = 0
    starts = set(starts)
    while i < len(s):
        if i in starts and i+1 < len(s):
            pair = html.escape(s[i:i+2])
            out.append(f"<mark>{pair}</mark>")
            i += 2
        else:
            out.append(html.escape(s[i]))
            i += 1
    return "".join(out)

def main():
    form = cgi.FieldStorage()
    word = form.getfirst("word", "").strip()

    print("Content-Type: text/html; charset=utf-8")
    print()  

    print("<!doctype html><html lang='uk'><head><meta charset='utf-8'>"
          "<title>Результат перевірки</title>"
          "<style>body{font-family:system-ui,Arial,sans-serif;margin:2rem}"
          "a{color:inherit}</style></head><body>")

    print("<h1>Результат перевірки</h1>")

    if not word:
        print("<p>Ви не ввели слово. <a href='/index.html'>Повернутися</a></p>")
        print("</body></html>")
        return

    doubles = find_doubles(word)
    highlighted = highlight_doubles(word, doubles)

    if doubles:
        print(f"<p>У слові знайдено подвоєння.</p>")
        print(f"<p><strong>Слово:</strong> {highlighted}</p>")
        print(f"<p>Кількість подвоєнь: {len(doubles)}</p>")
    else:
        print(f"<p>Подвоєння <strong>не знайдено</strong>.</p>")
        print(f"<p><strong>Слово:</strong> {html.escape(word)}</p>")

    print("<p><a href='/index.html'>Перевірити інше слово</a></p>")
    print("</body></html>")

if __name__ == '__main__':
    main()
