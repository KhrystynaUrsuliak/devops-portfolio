# Напишіть клас Person, який містить наступну інформацію: прізвище, ім’я, по-батькові та дата народження людини. У класі створіть метод, 
# який по заданій даті народження виводитиме повну кількість років людини. Напишіть клас Pilot, який наслідуватиме Person і доповнюватиме
# його наступною інформацією про пілота: ріст, вага, кількість годин, що пілот налітав. Обчисліть загальну кількість годин, що налітали усі
# пілоти, а також знайдіть найвищого пілота.

from person import Person
from pilot import Pilot
from datetime import date

if __name__ == "__main__":
    p1 = Pilot("Іваненко", "Іван", "Іванович", date(1985, 3, 12), 182, 80, 1500)
    p2 = Pilot("Петренко", "Петро", "Петрович", date(1990, 7, 24), 190, 85, 2300)
    p3 = Pilot("Сидоренко", "Олег", "Миколайович", date(1988, 12, 5), 176, 78, 1750)

    pilots = [p1, p2, p3]

    for pilot in pilots:
        print(f"Pilot: {pilot.first_name} {pilot.patronymic} {pilot.last_name}")
        print(f"Date of Birth: {pilot.date_of_birth}, Age: {pilot.calculate_age()}")
        print(f"Height: {pilot.height} cm, Weight: {pilot.weight} kg, Flight Time: {pilot.flight_hours} hours\n")

    total_hours = Pilot.calculate_total_flight_hours(pilots)
    tallest_pilot = Pilot.find_tallest_pilot(pilots)

    print(f"Total flight hours of all pilots: {total_hours} hours")
    print(f"Tallest pilot: {tallest_pilot.first_name} {tallest_pilot.patronymic} {tallest_pilot.last_name}, Height: {tallest_pilot.height} cm")