from person import Person

class Pilot(Person):
    def __init__(self, last_name, first_name, patronymic, date_of_birth, height, weight, flight_hours):
        super().__init__(last_name, first_name, patronymic, date_of_birth)
        self.height = height
        self.weight = weight
        self.flight_hours = flight_hours
        
    @staticmethod
    def calculate_total_flight_hours(pilots):
        return sum(pilot.flight_hours for pilot in pilots)
    
    @staticmethod
    def find_tallest_pilot(pilots):
        tallest = pilots[0]
        for pilot in pilots[1:]:
            if pilot.height > tallest.height:
                tallest = pilot
        return tallest
        