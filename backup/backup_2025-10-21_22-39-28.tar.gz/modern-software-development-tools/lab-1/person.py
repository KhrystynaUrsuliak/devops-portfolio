from datetime import date

class Person:
    def __init__(self, last_name, first_name, patronymic, date_of_birth):
        self.last_name = last_name
        self.first_name = first_name
        self.patronymic = patronymic
        self.date_of_birth = date_of_birth

    def calculate_age(self):
        today = date.today()
        age = today.year - self.date_of_birth.year

        if (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day):
            age -= 1

        return age
    