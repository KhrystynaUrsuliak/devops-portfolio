import sqlite3

conn = sqlite3.connect('hotels.db')
curs = conn.cursor()

tblcmd = '''
CREATE TABLE IF NOT EXISTS hotels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    city TEXT,
    country TEXT,
    rooms INTEGER,
    stars INTEGER,
    capacity INTEGER
)
'''
curs.execute(tblcmd)

hotels = [
    ("The Plaza", "New York", "USA", 282, 5, 600),
    ("The Ritz", "London", "UK", 190, 5, 450),
    ("The Ritz", "Paris", "France", 179, 5, 400),
    ("The Beverly Hills Hotel", "Los Angeles", "USA", 210, 5, 500),
    ("Waldorf Astoria", "New York", "USA", 375, 5, 800),
    ("Carlton Cannes", "Cannes", "France", 343, 5, 700),
    ("Hotel de Paris Monte-Carlo", "Monte Carlo", "Monaco", 283, 5, 600),
]

curs.executemany("""
INSERT INTO hotels (name, city, country, rooms, stars, capacity)
VALUES (?, ?, ?, ?, ?, ?)
""", hotels)

conn.commit()
conn.close()
