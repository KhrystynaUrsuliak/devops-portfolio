import shelve

with shelve.open('hotels') as db:
    db['1'] = {
        'name': 'The Plaza',
        'city': 'New Yourk',
        'country': 'USA',
        'rooms': 282,
        'stars': 5,
        'capacity': 600
    }

    db['2'] = {
        'name': 'The Ritz',
        'city': 'London',
        'country': 'UK',
        'rooms': 190,
        'stars': 5,
        'capacity': 450
    }

    db['3'] = {
        'name': 'The Ritz',
        'city': 'Paris',
        'country': 'France',
        'rooms': 179,
        'stars': 5,
        'capacity': 400
    }

    db['4'] = {
        'name': 'The Beverly Hills Hotel',
        'city': 'Los Angeles',
        'country': 'USA',
        'rooms': 210,
        'stars': 5,
        'capacity': 500
    }

    db['5'] = {
        'name': 'Waldorf Astoria',
        'city': 'New York',
        'country': 'USA',
        'rooms': 375,
        'stars': 5,
        'capacity': 800
    }

    db['6'] = {
        'name': 'Carlton Cannes',
        'city': 'Cannes',
        'country': 'France',
        'rooms': 343,
        'stars': 5,
        'capacity': 700
    }

    db['7'] = {
        'name': 'Hotel de Paris Monte-Carlo',
        'city': 'Monte Carlo',
        'country': 'Monaco',
        'rooms': 283,
        'stars': 5,
        'capacity': 600
    }


    def analyze_country(country):
        with shelve.open('hotels') as db:
            hotels = [db[key] for key in db if db[key]['country'] == country]

            if not hotels:
                print(f"No information found about hotels in {country}.")
                return

            average_stars = sum(hotel['stars'] for hotel in hotels) / len(hotels)
            largest_capacity = max(hotel['capacity'] for hotel in hotels)
            
            print(f"Average stars: {average_stars:.1f}")
            print(f"Largest capacity: {largest_capacity} guests")

    country = input("Enter country name: ")
    analyze_country(country)
