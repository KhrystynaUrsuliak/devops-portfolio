import sqlite3

def calculate_average_rating(country):
    conn = sqlite3.connect('hotels.db')
    curs = conn.cursor()

    curs.execute("""
                 SELECT AVG(stars) 
                 FROM hotels 
                 WHERE country = ?
                 """, (country,))
    
    average_stars = curs.fetchone()[0]
    conn.close()

    return average_stars

def find_largest_capacity(country):
    conn = sqlite3.connect('hotels.db')
    curs = conn.cursor()

    curs.execute("""
                 SELECT name, city, capacity
                 FROM hotels
                 WHERE country = ?
                 ORDER BY capacity DESC
                 """, (country,))
    
    largest_hotel = curs.fetchone()
    conn.close()

    return largest_hotel

if __name__ == "__main__":
    country = input("Enter the country name: ")

    avg_rating = calculate_average_rating(country)
    if avg_rating is not None:
        print(f"Average star rating in {country}: {avg_rating:.2f}")
    else:
        print(f"No information found about hotels in {country}.")

    largest_hotel = find_largest_capacity(country)
    if largest_hotel:
        name, city, capacity = largest_hotel
        print(f"Largest hotel is in {country}: {name} in {city} with a capacity of {capacity} guests.")
    else:
        print(f"No information found about hotels in {country}.")

