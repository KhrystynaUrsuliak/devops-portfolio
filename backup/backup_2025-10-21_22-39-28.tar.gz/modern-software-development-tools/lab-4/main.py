# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox

def case_eq(a: str, b: str) -> bool:
    return a.casefold() == b.casefold()

def is_letter(ch: str) -> bool:
    return ch.isalpha()

def find_doubles(s: str):
    indexes = []
    for i in range(len(s) - 1):
        if is_letter(s[i]) and is_letter(s[i+1]) and case_eq(s[i], s[i+1]):
            indexes.append(i)
    return indexes

def find_repetitions(s: str):
    pos = {}
    for i, ch in enumerate(s):
        if is_letter(ch):
            key = ch.casefold()
            pos.setdefault(key, []).append(i)
    return {k: v for k, v in pos.items() if len(v) >= 2}

def clear_highlight():
    txt.config(state="normal")
    txt.delete("1.0", "end")
    txt.tag_delete("mark")
    txt.tag_configure("mark", background="#fff2a8")
    txt.config(state="disabled")

def show_highlight(s: str, ranges):
    txt.config(state="normal")
    txt.delete("1.0", "end")
    txt.insert("1.0", s)
    txt.tag_delete("mark")
    txt.tag_configure("mark", background="#fff2a8")
    for a, b in ranges:
        start_idx = f"1.0 + {a} chars"
        end_idx   = f"1.0 + {b} chars"
        txt.tag_add("mark", start_idx, end_idx)
    txt.config(state="disabled")

def run_check(*_):
    s = entry.get()
    if not s:
        messagebox.showinfo("Порожній ввід", "Введіть слово для перевірки.")
        return

    mode = mode_var.get()
    if mode == "double":
        starts = find_doubles(s)
        if starts:
            ranges = [(i, i+2) for i in starts]
            show_highlight(s, ranges)
            info = ", ".join(f"{i}-{i+1}" for i in starts)
            result_var.set(f"Знайдено подвоєння на індексах: {info}")
        else:
            clear_highlight()
            show_highlight(s, [])
            result_var.set("Подвоєнь не знайдено.")
    else:  
        reps = find_repetitions(s)
        if reps:
            ranges = []
            for indexes in reps.values():
                for i in indexes:
                    ranges.append((i, i+1))
            show_highlight(s, ranges)
            parts = []
            for ch, indexes in sorted(reps.items()):
                parts.append(f"«{ch}» → {indexes}")
            result_var.set("Повторення літер: " + ";  ".join(parts))
        else:
            clear_highlight()
            show_highlight(s, [])
            result_var.set("Повторень літер не знайдено.")

root = tk.Tk()
root.title("Перевірка подвоєнь / повторень літер")

main = ttk.Frame(root, padding=12)
main.grid(row=0, column=0, sticky="nsew")
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

ttk.Label(main, text="Слово:").grid(row=0, column=0, sticky="w")
entry = ttk.Entry(main, width=40)
entry.grid(row=0, column=1, columnspan=3, sticky="ew", padx=(6, 0))
main.columnconfigure(3, weight=1)

mode_var = tk.StringVar(value="double")
rb1 = ttk.Radiobutton(main, text="Шукати подвоєння (дві однакові поруч)",
                      variable=mode_var, value="double", command=run_check)
rb2 = ttk.Radiobutton(main, text="Шукати повторення літер (будь-де)",
                      variable=mode_var, value="repeat", command=run_check)
rb1.grid(row=1, column=0, columnspan=4, sticky="w", pady=(8, 0))
rb2.grid(row=2, column=0, columnspan=4, sticky="w")

btn = ttk.Button(main, text="Перевірити", command=run_check)
btn.grid(row=3, column=0, columnspan=1, pady=(10, 6), sticky="w")

result_var = tk.StringVar(value="—")
res_lbl = ttk.Label(main, textvariable=result_var, foreground="#333")
res_lbl.grid(row=4, column=0, columnspan=4, sticky="w", pady=(6, 4))

txt = tk.Text(main, height=3, width=50, wrap="none")
txt.grid(row=5, column=0, columnspan=4, sticky="ew")
txt.config(state="disabled")

entry.bind("<Return>", run_check)
entry.focus_set()

root.mainloop()
