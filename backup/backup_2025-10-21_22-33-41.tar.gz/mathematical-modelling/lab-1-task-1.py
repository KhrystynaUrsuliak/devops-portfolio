import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

r = 0.5    
K = 100     

def verhulst_classic(t, N):
    return r * N * (1 - N / K)

def verhulst_general(t, N):
    return r * N * (1 - (N / K) ** 3)

t_span = (0, 20)
t_eval = np.linspace(*t_span, 400)

N0_values = [10, 80, 120]

classic_solutions = [solve_ivp(verhulst_classic, t_span, [N0], t_eval=t_eval) for N0 in N0_values]
general_solutions = [solve_ivp(verhulst_general, t_span, [N0], t_eval=t_eval) for N0 in N0_values]

plt.figure(figsize=(8, 5))
for sol_g, N0 in zip(general_solutions, N0_values):
    plt.plot(sol_g.t, sol_g.y[0], label=f"N₀={N0}")

plt.axhline(K, color="gray", linestyle="--", label="N = K (стаціонарна)")

plt.title(r"Узагальнена модель Ферхюльста: $\ \frac{dN}{dt} = rN\left(1 - \left(\frac{N}{K}\right)^3\right)$")

plt.xlabel("t")
plt.ylabel("N(t)")
plt.legend()
plt.grid(True)
plt.show()


plt.figure(figsize=(9, 5))
for sol_c, sol_g, N0 in zip(classic_solutions, general_solutions, N0_values):
    plt.plot(sol_c.t, sol_c.y[0], '--', label=f"Класична (N₀={N0})")
    plt.plot(sol_g.t, sol_g.y[0], '-', label=f"Узагальнена (N₀={N0})")
plt.axhline(K, color="gray", linestyle="--", label="N = K (стаціонарна)")
plt.title("Порівняння: класична та узагальнена моделі Ферхюльста")
plt.xlabel("t")
plt.ylabel("N(t)")
plt.legend()
plt.grid(True)
plt.show()

N_values = np.linspace(0, 150, 300)
dN_classic = r * N_values * (1 - N_values / K)
dN_general = r * N_values * (1 - (N_values / K) ** 3)

plt.figure(figsize=(7, 4))
plt.plot(N_values, dN_classic, label="Класична модель", linestyle="--")
plt.plot(N_values, dN_general, label="Узагальнена модель (n=3)", color="darkred")
plt.axhline(0, color="black", linewidth=0.8)
plt.axvline(K, color="gray", linestyle="--")
plt.title("Фазова діаграма:")
plt.xlabel("N")
plt.ylabel("dN/dt")
plt.legend()
plt.grid(True)
plt.show()
